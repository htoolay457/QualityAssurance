# QualityAssurance

1. Fork this repository into your own.  Do this by clicking the Fork button on the top right of this page (pictured below)
   1. ![Fork Image](Fork%20image.jpg)
   2. Forking is making a copy of a repository.  This will be acopy that you'll be able to change, test, etc as much as you'd like.
   3. Documentation on Forking = https://help.github.com/en/github/getting-started-with-github/fork-a-repo
   
2. Navigate to your repositories
   1. Click on your account icon at the top right of the screen
      * ![Fork Image](Icon.jpg)
   2. click on repositories.
      * ![Fork Image](Profile%20Repo.jpg)
      
3. You should have QualityAssurance listed in your repository now.  Click on it
   * ![Fork Image](QualityAssurance.jpg)
   
4. Click the green Clone or Download button

5. Copy the HTTP URL
   * ![Fork Image](Clone%20with%20HTTPS.jpg)
   2. it should look similar to https://github.com/(Your User Name Here)/QualityAssurance.git
   3. If it says Use HTTP on the top right click that. Otherwise you will receive the SSH URL.
   
6. Clone your forked copy into GitHubDesktop
   * ![Fork Image](QualityAssurance.jpg)
   
7. Change the ChangeMe Document. 
   1. Add your first and last name on one line.
   2. Do not delete others names.
